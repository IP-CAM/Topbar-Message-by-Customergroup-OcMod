<?php
class ControllerExtensionModuleTopBar extends Controller {
	
	public function displayTopBar(&$eventRoute, &$data, &$output) {
		$this->load->model('localisation/language');
		$this->load->model('setting/setting');

		$status = $this->model_setting_setting->getSettingValue('module_topbar_status');
		if ($status != '1') return;

		$languages = $this->model_localisation_language->getLanguages();
		$session_language_id = $languages[$this->session->data['language']]['language_id'];

		$settings = json_decode($this->model_setting_setting->getSettingValue('module_topbar_data'), true);
		if (empty($settings['color'])) $settings['color'] = '#ffffff';
		if (empty($settings['bgcolor'])) $settings['bgcolor'] = '#808080';
		
		if (empty($settings['vpadding'])) {
			$settings['vpadding'] = '20px';
		} else {
			$settings['vpadding'] .= 'px';
		}
		
		if (empty($settings['fontsize'])) {
			$settings['fontsize'] = '15px';
		} else {
			$settings['fontsize'] .= 'px';
		}
		
		//html_entity_decode($setting['message'][$session_language_id], ENT_QUOTES, 'UTF-8');
		//if (empty($settings['message'][$session_language_id])) $settings['message'][$session_language_id] = '';
		$data['message'] = html_entity_decode($settings['message'][$session_language_id] ? $settings['message'][$session_language_id] : '', ENT_QUOTES, 'UTF-8');
		
		$elem = '
		<div id="topbar">
			<div class="topbar-msg">' . $data['message'] . '</div>
		</div>
		';

		$style = '
		<style>
			#topbar {
				text-align: center;
				background-color: ' . $settings['bgcolor'] . ';
				padding-top: ' . $settings['vpadding'] . ';
				padding-bottom: ' . $settings['vpadding'] . ';
			}
			#topbar .topbar-msg {
				line-height: 1.5;
				color: ' . $settings['color'] . ';
				font-size: ' . $settings['fontsize'] . ';
			}
		</style>
		';

		$out = '';
		$lines = @explode("\n", $output);
		foreach ($lines as $line) {
			if ($this->startsWith(trim($line), '</head>')) $line = $style . $line;
			if ($this->startsWith(trim($line), '<body')) $line = $line . $elem;
			$out .= $line . "\n";
		}
		
		$output = $out;
	}

	private function startsWith($haystack, $needle) {
		return $needle === "" || mb_strpos($haystack, $needle) === 0;
	}
}
