<?php
// Heading
$_['heading_title']     	= 'TopBar';

// Text
$_['text_extension']   		= 'Extensions';
$_['text_success']     		= 'Success: You have modified Top Bar module!';
$_['text_edit']       	 	= 'Edit Top Bar Module';
$_['text_save_stay']   		= '(stay on form)';

// Entry
$_['entry_status']     		= 'Status';
$_['entry_color']     		= 'Color';
$_['entry_bgcolor']     	= 'Background Color';
$_['entry_vpadding']     	= 'Padding (vertical)';
$_['entry_fontsize']     	= 'Font Size';
$_['entry_message']     	= 'Message';

// Error
$_['error_warning'] 			= 'Warning: Please check the form carefully for errors!';
$_['error_permission'] 		= 'Warning: You do not have permission to modify Top Bar module!';
$_['error_color'] 				= 'Color is required!';
$_['error_bgcolor'] 			= 'Background Color is required!';
$_['error_vpadding'] 			= 'Padding (vertical) is required!';
$_['error_fontsize'] 			= 'Font Size is required!';
$_['error_message'] 			= 'Message is required!';
